# collection box > 2023-11-21 6:17am
https://universe.roboflow.com/project-fyk0c/collection-box

Provided by a Roboflow user
License: CC BY 4.0

